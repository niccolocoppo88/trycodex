Rails.application.routes.draw do
  root "pages#home"
end